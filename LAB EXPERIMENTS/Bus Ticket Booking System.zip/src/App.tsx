import { useMemo, useState } from "react";

type IconName =
  | "arrow"
  | "bus"
  | "calendar"
  | "check"
  | "clock"
  | "map"
  | "shield"
  | "ticket"
  | "users";

function Icon({ name, className = "h-5 w-5" }: { name: IconName; className?: string }) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: <path d="M7 7h10m0 0-3-3m3 3-3 3M17 17H7m0 0 3 3m-3-3 3-3" />,
    bus: (
      <>
        <path d="M5 16V6.5C5 4.6 6.6 3 8.5 3h7C17.4 3 19 4.6 19 6.5V16" />
        <path d="M5 11h14M8 7h8M7 16h10M7 16v2m10-2v2" />
        <circle cx="8" cy="14" r=".7" fill="currentColor" stroke="none" />
        <circle cx="16" cy="14" r=".7" fill="currentColor" stroke="none" />
      </>
    ),
    calendar: (
      <>
        <path d="M6 3v3m12-3v3M4 9h16M5 5h14a1 1 0 0 1 1 1v14H4V6a1 1 0 0 1 1-1Z" />
        <path d="M8 13h2m4 0h2m-8 4h2m4 0h2" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    map: (
      <>
        <path d="m4 6 5-2 6 2 5-2v14l-5 2-6-2-5 2V6Z" />
        <path d="M9 4v14m6-12v14" />
      </>
    ),
    shield: <path d="M12 3 5 6v5c0 4.6 2.9 8.1 7 10 4.1-1.9 7-5.4 7-10V6l-7-3Zm-3 9 2 2 4-4" />,
    ticket: (
      <>
        <path d="M4 7h16v3a2 2 0 0 0 0 4v3H4v-3a2 2 0 0 0 0-4V7Z" />
        <path d="M12 7v2m0 2v2m0 2v2" />
      </>
    ),
    users: (
      <>
        <circle cx="9" cy="8" r="3" />
        <path d="M3 20v-2a5 5 0 0 1 5-5h2a5 5 0 0 1 5 5v2m1-7a4 4 0 0 1 5 4v2" />
        <path d="M16 5.5a3 3 0 0 1 0 5.8" />
      </>
    ),
  };

  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

const popularRoutes = [
  { from: "New York", to: "Boston", time: "4h 15m", price: "$29" },
  { from: "Chicago", to: "Detroit", time: "5h 05m", price: "$34" },
  { from: "Seattle", to: "Portland", time: "3h 20m", price: "$24" },
];

const departures = [
  { company: "Northline", depart: "07:30", arrive: "11:45", price: "$29", tag: "Best value" },
  { company: "Roam Express", depart: "09:15", arrive: "13:20", price: "$36", tag: "Fastest" },
  { company: "Greenway", depart: "12:00", arrive: "16:30", price: "$31", tag: "Low emissions" },
];

function App() {
  const defaultDate = useMemo(() => {
    const date = new Date();
    date.setDate(date.getDate() + 7);
    return date.toISOString().slice(0, 10);
  }, []);
  const [from, setFrom] = useState("New York");
  const [to, setTo] = useState("Boston");
  const [date, setDate] = useState(defaultDate);
  const [passengers, setPassengers] = useState("1");
  const [searched, setSearched] = useState(false);

  const swapLocations = () => {
    setFrom(to);
    setTo(from);
  };

  return (
    <div className="min-h-screen bg-[#f4f1e8] text-[#173c34]">
      <header className="border-b border-[#173c34]/10 bg-[#f4f1e8]/95">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 md:px-8">
          <button
            className="flex items-center gap-3 text-left"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            aria-label="Roamly home"
          >
            <span className="grid h-10 w-10 place-items-center rounded-full bg-[#173c34] text-[#f4f1e8]">
              <Icon name="bus" className="h-5 w-5" />
            </span>
            <span className="text-xl font-black tracking-[-0.04em]">ROAMLY</span>
          </button>

          <nav className="hidden items-center gap-8 text-sm font-semibold md:flex" aria-label="Main navigation">
            <a className="transition-opacity hover:opacity-60" href="#routes">Routes</a>
            <a className="transition-opacity hover:opacity-60" href="#how-it-works">How it works</a>
            <a className="transition-opacity hover:opacity-60" href="#why-roamly">Why Roamly</a>
          </nav>

          <button className="rounded-full border border-[#173c34]/20 px-5 py-2.5 text-sm font-bold transition hover:bg-[#173c34] hover:text-white">
            My trips
          </button>
        </div>
      </header>

      <main>
        <section className="mx-auto max-w-7xl px-5 pb-14 pt-14 md:px-8 md:pb-20 md:pt-20">
          <div className="grid items-end gap-12 lg:grid-cols-[1.3fr_.7fr]">
            <div>
              <div className="mb-6 flex items-center gap-3 text-xs font-black uppercase tracking-[0.2em] text-[#e95d3f]">
                <span className="h-px w-10 bg-[#e95d3f]" />
                Travel feels better this way
              </div>
              <h1 className="max-w-4xl font-serif text-5xl leading-[0.96] tracking-[-0.055em] sm:text-6xl md:text-8xl">
                Your next stop is closer than you think.
              </h1>
            </div>
            <div className="border-l border-[#173c34]/20 pl-6 lg:pb-2">
              <p className="max-w-md text-base leading-7 text-[#173c34]/70">
                Compare trusted bus operators, choose your favorite seat, and book your journey in minutes.
              </p>
              <div className="mt-5 flex items-center gap-5 text-sm font-bold">
                <span className="flex items-center gap-2"><Icon name="check" className="h-4 w-4 text-[#e95d3f]" /> No booking fees</span>
                <span className="flex items-center gap-2"><Icon name="check" className="h-4 w-4 text-[#e95d3f]" /> Easy changes</span>
              </div>
            </div>
          </div>

          <form
            className="relative z-10 mt-12 bg-white p-3 shadow-[0_25px_60px_rgba(23,60,52,0.12)] md:p-4"
            onSubmit={(event) => {
              event.preventDefault();
              setSearched(true);
              requestAnimationFrame(() => document.querySelector("#results")?.scrollIntoView({ behavior: "smooth" }));
            }}
          >
            <div className="grid gap-2 md:grid-cols-[1.15fr_3rem_1.15fr_.9fr_.75fr_auto] md:items-stretch">
              <label className="group flex min-w-0 items-center gap-3 bg-[#f4f1e8]/70 px-4 py-3">
                <Icon name="map" className="h-5 w-5 shrink-0 text-[#e95d3f]" />
                <span className="min-w-0 flex-1">
                  <span className="block text-[10px] font-black uppercase tracking-[0.16em] text-[#173c34]/50">Leaving from</span>
                  <input
                    className="mt-1 w-full bg-transparent text-base font-bold outline-none placeholder:text-[#173c34]/30"
                    value={from}
                    onChange={(event) => setFrom(event.target.value)}
                    aria-label="Leaving from"
                    required
                  />
                </span>
              </label>

              <button
                className="mx-auto grid h-11 w-11 place-items-center self-center rounded-full border border-[#173c34]/15 bg-white transition hover:rotate-180 hover:border-[#173c34] md:-mx-1"
                type="button"
                onClick={swapLocations}
                aria-label="Swap departure and destination"
              >
                <Icon name="arrow" className="h-4 w-4" />
              </button>

              <label className="flex min-w-0 items-center gap-3 bg-[#f4f1e8]/70 px-4 py-3">
                <Icon name="map" className="h-5 w-5 shrink-0 text-[#e95d3f]" />
                <span className="min-w-0 flex-1">
                  <span className="block text-[10px] font-black uppercase tracking-[0.16em] text-[#173c34]/50">Going to</span>
                  <input
                    className="mt-1 w-full bg-transparent text-base font-bold outline-none"
                    value={to}
                    onChange={(event) => setTo(event.target.value)}
                    aria-label="Going to"
                    required
                  />
                </span>
              </label>

              <label className="flex items-center gap-3 bg-[#f4f1e8]/70 px-4 py-3">
                <Icon name="calendar" className="h-5 w-5 shrink-0 text-[#e95d3f]" />
                <span className="min-w-0 flex-1">
                  <span className="block text-[10px] font-black uppercase tracking-[0.16em] text-[#173c34]/50">Travel date</span>
                  <input
                    className="mt-1 w-full bg-transparent text-sm font-bold outline-none"
                    type="date"
                    value={date}
                    onChange={(event) => setDate(event.target.value)}
                    aria-label="Travel date"
                    required
                  />
                </span>
              </label>

              <label className="flex items-center gap-3 bg-[#f4f1e8]/70 px-4 py-3">
                <Icon name="users" className="h-5 w-5 shrink-0 text-[#e95d3f]" />
                <span className="min-w-0 flex-1">
                  <span className="block text-[10px] font-black uppercase tracking-[0.16em] text-[#173c34]/50">Travelers</span>
                  <select
                    className="mt-1 w-full bg-transparent text-sm font-bold outline-none"
                    value={passengers}
                    onChange={(event) => setPassengers(event.target.value)}
                    aria-label="Number of travelers"
                  >
                    <option value="1">1 adult</option>
                    <option value="2">2 adults</option>
                    <option value="3">3 adults</option>
                    <option value="4">4 adults</option>
                  </select>
                </span>
              </label>

              <button className="bg-[#e95d3f] px-7 py-4 text-sm font-black text-white transition hover:bg-[#d84b31]" type="submit">
                Search buses
              </button>
            </div>
          </form>
        </section>

        {searched && (
          <section id="results" className="border-y border-[#173c34]/10 bg-white px-5 py-14 md:px-8">
            <div className="mx-auto max-w-7xl">
              <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
                <div>
                  <p className="text-xs font-black uppercase tracking-[0.2em] text-[#e95d3f]">Available journeys</p>
                  <h2 className="mt-2 font-serif text-4xl tracking-[-0.04em]">{from} to {to}</h2>
                </div>
                <p className="text-sm font-semibold text-[#173c34]/60">{departures.length} departures · {passengers} traveler{passengers !== "1" ? "s" : ""}</p>
              </div>
              <div className="space-y-3">
                {departures.map((trip) => (
                  <article key={trip.company} className="grid items-center gap-5 border border-[#173c34]/10 p-5 transition hover:border-[#173c34]/40 md:grid-cols-[1fr_1.4fr_.7fr_auto]">
                    <div>
                      <span className="text-xs font-black uppercase tracking-[0.15em] text-[#e95d3f]">{trip.tag}</span>
                      <p className="mt-1 font-bold">{trip.company}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <strong className="text-xl">{trip.depart}</strong>
                      <span className="h-px flex-1 bg-[#173c34]/20" />
                      <Icon name="bus" className="h-5 w-5 text-[#173c34]/50" />
                      <span className="h-px flex-1 bg-[#173c34]/20" />
                      <strong className="text-xl">{trip.arrive}</strong>
                    </div>
                    <div className="flex items-center gap-2 text-sm font-semibold text-[#173c34]/60">
                      <Icon name="clock" className="h-4 w-4" /> Direct · 4h 15m
                    </div>
                    <button className="bg-[#173c34] px-5 py-3 text-sm font-black text-white transition hover:bg-[#e95d3f]">
                      {trip.price}
                    </button>
                  </article>
                ))}
              </div>
            </div>
          </section>
        )}

        <section id="routes" className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-24">
          <div className="mb-10 flex flex-wrap items-end justify-between gap-5">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#e95d3f]">Go somewhere good</p>
              <h2 className="mt-3 font-serif text-4xl tracking-[-0.04em] md:text-5xl">Popular right now</h2>
            </div>
            <a className="border-b border-[#173c34] pb-1 text-sm font-black" href="#routes">Explore all routes</a>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            {popularRoutes.map((route, index) => (
              <button
                key={route.from}
                className="group border border-[#173c34]/15 bg-transparent p-6 text-left transition hover:-translate-y-1 hover:bg-white hover:shadow-[0_18px_40px_rgba(23,60,52,0.09)]"
                onClick={() => {
                  setFrom(route.from);
                  setTo(route.to);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
              >
                <div className="flex items-start justify-between">
                  <span className="text-xs font-black text-[#173c34]/40">0{index + 1}</span>
                  <span className="grid h-10 w-10 place-items-center rounded-full border border-[#173c34]/15 transition group-hover:bg-[#e95d3f] group-hover:text-white">
                    <Icon name="arrow" className="h-4 w-4 rotate-90" />
                  </span>
                </div>
                <div className="mt-12 flex items-center gap-3 text-2xl font-black tracking-[-0.04em]">
                  <span>{route.from}</span><span className="text-[#e95d3f]">→</span><span>{route.to}</span>
                </div>
                <div className="mt-4 flex items-center justify-between text-sm font-semibold text-[#173c34]/60">
                  <span>{route.time} · Direct</span>
                  <span>from <strong className="text-[#173c34]">{route.price}</strong></span>
                </div>
              </button>
            ))}
          </div>
        </section>

        <section id="how-it-works" className="bg-[#173c34] text-white">
          <div className="mx-auto grid max-w-7xl lg:grid-cols-2">
            <div className="flex flex-col justify-center px-5 py-16 md:px-12 md:py-24 lg:px-16">
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#f38a71]">Simple from start to finish</p>
              <h2 className="mt-4 max-w-lg font-serif text-4xl leading-tight tracking-[-0.04em] md:text-5xl">More road. Less runaround.</h2>
              <div className="mt-10 space-y-8">
                {[
                  ["01", "Find your route", "Search hundreds of daily departures in seconds."],
                  ["02", "Pick your seat", "Choose the time, operator, and comfort level that suit you."],
                  ["03", "Ride easy", "Your digital ticket is ready instantly. No printing needed."],
                ].map(([number, title, copy]) => (
                  <div className="grid grid-cols-[3rem_1fr] gap-4" key={number}>
                    <span className="font-mono text-sm text-[#f38a71]">{number}</span>
                    <div>
                      <h3 className="font-bold">{title}</h3>
                      <p className="mt-1 text-sm leading-6 text-white/60">{copy}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <figure className="relative min-h-[28rem] overflow-hidden">
              <img
                className="absolute inset-0 h-full w-full object-cover"
                src="https://images.unsplash.com/photo-1790360740621-41c1861d78e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxtb2Rlcm4lMjBjb2FjaCUyMGJ1cyUyMG1vdW50YWluJTIwcm9hZCUyMHRyYXZlbCUyMGxhbmRzY2FwZXxlbnwxfHx8fDE3OTEyNzMwMDZ8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="A coach bus traveling toward a mountain"
              />
              <figcaption className="absolute bottom-5 right-5 bg-[#f4f1e8] px-4 py-3 text-xs font-bold text-[#173c34]">
                Photo by Arlind Photography
              </figcaption>
            </figure>
          </div>
        </section>

        <section id="why-roamly" className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-24">
          <div className="grid gap-10 border-b border-[#173c34]/15 pb-16 md:grid-cols-3">
            {[
              ["ticket", "One simple ticket", "Everything you need lives in your phone, even offline."],
              ["shield", "Book with confidence", "Trusted operators, secure payments, and real support."],
              ["clock", "Plans can change", "Flexible tickets make changes simple when life happens."],
            ].map(([icon, title, copy]) => (
              <div key={title} className="max-w-sm">
                <Icon name={icon as IconName} className="h-8 w-8 text-[#e95d3f]" />
                <h3 className="mt-6 text-lg font-black">{title}</h3>
                <p className="mt-2 text-sm leading-6 text-[#173c34]/60">{copy}</p>
              </div>
            ))}
          </div>
        </section>
      </main>

      <footer className="px-5 pb-10 md:px-8">
        <div className="mx-auto flex max-w-7xl flex-col justify-between gap-4 text-sm text-[#173c34]/55 md:flex-row">
          <p>© 2025 Roamly. Your road starts here.</p>
          <div className="flex gap-6">
            <a href="#why-roamly">Help</a>
            <a href="#why-roamly">Terms</a>
            <a href="#why-roamly">Privacy</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
