import { useMemo, useState } from "react";

type IconName =
  | "home"
  | "search"
  | "heart"
  | "bag"
  | "user"
  | "arrow"
  | "chevron"
  | "close"
  | "minus"
  | "plus"
  | "check"
  | "sparkle";

type Product = {
  id: number;
  name: string;
  category: string;
  price: number;
  image: string;
  tone: string;
  badge?: string;
};

const products: Product[] = [
  {
    id: 1,
    name: "Sculpted Mini Bag",
    category: "Accessories",
    price: 128,
    image:
      "https://images.unsplash.com/photo-1683921377994-928bd73b889f?auto=format&fit=crop&w=900&q=88",
    tone: "Ivory",
    badge: "New",
  },
  {
    id: 2,
    name: "Everyday Runner",
    category: "Shoes",
    price: 96,
    image:
      "https://images.unsplash.com/photo-1677055089360-c2aa1ac5d20e?auto=format&fit=crop&w=900&q=88",
    tone: "Cloud",
  },
  {
    id: 3,
    name: "Soft Tailored Coat",
    category: "Clothing",
    price: 184,
    image:
      "https://images.unsplash.com/photo-1593764058442-ec2c37d58f80?auto=format&fit=crop&w=900&q=88",
    tone: "Camel",
    badge: "Limited",
  },
  {
    id: 4,
    name: "Relaxed Oxford",
    category: "Clothing",
    price: 72,
    image:
      "https://images.unsplash.com/photo-1580682312385-e94d8de1cf3c?auto=format&fit=crop&w=900&q=88",
    tone: "Chalk",
  },
];

const categories = ["All", "Clothing", "Shoes", "Accessories"];

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    home: <><path d="m3 10 9-7 9 7" /><path d="M5 9v11h14V9" /><path d="M9 20v-6h6v6" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />,
    bag: <><path d="M5 8h14l-1 13H6L5 8Z" /><path d="M9 10V6a3 3 0 0 1 6 0v4" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    arrow: <><path d="M5 12h14" /><path d="m14 7 5 5-5 5" /></>,
    chevron: <path d="m9 18 6-6-6-6" />,
    close: <><path d="m6 6 12 12" /><path d="m18 6-12 12" /></>,
    minus: <path d="M5 12h14" />,
    plus: <><path d="M5 12h14" /><path d="M12 5v14" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    sparkle: <><path d="m12 3 1.2 4.2L17 9l-3.8 1.8L12 15l-1.2-4.2L7 9l3.8-1.8L12 3Z" /><path d="m19 15 .6 2.1 1.9.9-1.9.9L19 21l-.6-2.1-1.9-.9 1.9-.9L19 15Z" /></>,
  };

  return (
    <svg
      aria-hidden="true"
      fill="none"
      height={size}
      viewBox="0 0 24 24"
      width={size}
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.7"
    >
      {paths[name]}
    </svg>
  );
}

export default function App() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [favorites, setFavorites] = useState<number[]>([3]);
  const [cart, setCart] = useState<Record<number, number>>({});
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [added, setAdded] = useState(false);

  const visibleProducts = useMemo(
    () =>
      activeCategory === "All"
        ? products
        : products.filter((product) => product.category === activeCategory),
    [activeCategory],
  );

  const cartCount = Object.values(cart).reduce((sum, quantity) => sum + quantity, 0);
  const cartTotal = Object.entries(cart).reduce((sum, [id, quantity]) => {
    const product = products.find((item) => item.id === Number(id));
    return sum + (product?.price ?? 0) * quantity;
  }, 0);

  const toggleFavorite = (id: number) => {
    setFavorites((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  };

  const addToCart = (product: Product) => {
    setCart((current) => ({ ...current, [product.id]: (current[product.id] ?? 0) + 1 }));
    setAdded(true);
    window.setTimeout(() => setAdded(false), 1600);
  };

  const updateQuantity = (id: number, change: number) => {
    setCart((current) => {
      const next = (current[id] ?? 0) + change;
      if (next <= 0) {
        const { [id]: _, ...rest } = current;
        return rest;
      }
      return { ...current, [id]: next };
    });
  };

  return (
    <main className="prototype-shell">
      <section className="phone-frame" aria-label="North mobile shop prototype">
        <div className="status-bar">
          <span>9:41</span>
          <div className="status-icons" aria-hidden="true">
            <span className="signal" />
            <span className="wifi">◠</span>
            <span className="battery"><span /></span>
          </div>
        </div>

        <div className="app-scroll">
          <header className="app-header">
            <button className="brand" aria-label="Go to home">NORTH<span>.</span></button>
            <button className="icon-button bag-button" onClick={() => setCartOpen(true)} aria-label="Open shopping bag">
              <Icon name="bag" size={22} />
              {cartCount > 0 && <span className="cart-count">{cartCount}</span>}
            </button>
          </header>

          <section className="intro">
            <p className="eyebrow">Curated for everyday</p>
            <h1>Find your<br /><em>new favorite.</em></h1>
            <p className="intro-copy">Thoughtful pieces designed to stay in your rotation.</p>
          </section>

          <button className="search-bar" type="button">
            <Icon name="search" size={19} />
            <span>Search our collection</span>
            <kbd>⌘ K</kbd>
          </button>

          <div className="category-scroll" aria-label="Product categories">
            {categories.map((category) => (
              <button
                className={activeCategory === category ? "category active" : "category"}
                key={category}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>

          <section className="feature-card">
            <img
              src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&w=1100&q=90"
              alt="Neutral clothing arranged on a rail"
            />
            <div className="feature-shade" />
            <div className="feature-content">
              <span>THE EDIT · 01</span>
              <h2>Soft structure,<br />made simple.</h2>
              <button type="button" onClick={() => setActiveCategory("Clothing")}>
                Shop the edit <Icon name="arrow" size={18} />
              </button>
            </div>
          </section>

          <section className="product-section">
            <div className="section-heading">
              <div>
                <p>JUST IN</p>
                <h2>Fresh finds</h2>
              </div>
              <button onClick={() => setActiveCategory("All")}>View all <Icon name="chevron" size={16} /></button>
            </div>

            <div className="product-grid">
              {visibleProducts.map((product) => (
                <article className="product-card" key={product.id}>
                  <button className="product-image" onClick={() => setSelectedProduct(product)} aria-label={`View ${product.name}`}>
                    <img src={product.image} alt={product.name} />
                    {product.badge && <span className="badge">{product.badge}</span>}
                  </button>
                  <button
                    className={favorites.includes(product.id) ? "favorite active" : "favorite"}
                    onClick={() => toggleFavorite(product.id)}
                    aria-label={favorites.includes(product.id) ? "Remove from favorites" : "Add to favorites"}
                  >
                    <Icon name="heart" size={18} />
                  </button>
                  <button className="product-info" onClick={() => setSelectedProduct(product)}>
                    <span>{product.category}</span>
                    <h3>{product.name}</h3>
                    <p>${product.price}</p>
                  </button>
                </article>
              ))}
            </div>
          </section>

          <section className="perks">
            <Icon name="sparkle" size={22} />
            <div><strong>Better basics, better choices.</strong><span>Free shipping over $100 · 30-day returns</span></div>
          </section>
        </div>

        <nav className="bottom-nav" aria-label="Primary navigation">
          {[
            ["home", "Home"],
            ["search", "Discover"],
            ["heart", "Saved"],
            ["user", "Profile"],
          ].map(([icon, label], index) => (
            <button className={index === 0 ? "active" : ""} key={label}>
              <Icon name={icon as IconName} size={21} />
              <span>{label}</span>
              {index === 2 && favorites.length > 0 && <i>{favorites.length}</i>}
            </button>
          ))}
        </nav>

        {selectedProduct && (
          <div className="overlay" onClick={() => setSelectedProduct(null)}>
            <article className="product-sheet" onClick={(event) => event.stopPropagation()}>
              <button className="sheet-close" onClick={() => setSelectedProduct(null)} aria-label="Close product details">
                <Icon name="close" size={20} />
              </button>
              <div className="sheet-image">
                <img src={selectedProduct.image} alt={selectedProduct.name} />
              </div>
              <div className="sheet-content">
                <p className="eyebrow">{selectedProduct.category}</p>
                <div className="sheet-title">
                  <h2>{selectedProduct.name}</h2>
                  <button
                    className={favorites.includes(selectedProduct.id) ? "favorite-inline active" : "favorite-inline"}
                    onClick={() => toggleFavorite(selectedProduct.id)}
                    aria-label="Toggle favorite"
                  >
                    <Icon name="heart" size={20} />
                  </button>
                </div>
                <p className="sheet-price">${selectedProduct.price}</p>
                <div className="color-row"><span>Color</span><strong><i />{selectedProduct.tone}</strong></div>
                <p className="description">An elevated essential with clean lines, considered details, and an easy everyday feel.</p>
                <button className={added ? "primary-button added" : "primary-button"} onClick={() => addToCart(selectedProduct)}>
                  {added ? <><Icon name="check" size={19} /> Added to bag</> : <>Add to bag <span>${selectedProduct.price}</span></>}
                </button>
              </div>
            </article>
          </div>
        )}

        {cartOpen && (
          <div className="overlay" onClick={() => setCartOpen(false)}>
            <aside className="cart-sheet" onClick={(event) => event.stopPropagation()}>
              <div className="cart-header">
                <div><p className="eyebrow">YOUR SELECTION</p><h2>Shopping bag <span>({cartCount})</span></h2></div>
                <button className="sheet-close static" onClick={() => setCartOpen(false)} aria-label="Close bag"><Icon name="close" size={20} /></button>
              </div>
              <div className="cart-items">
                {cartCount === 0 ? (
                  <div className="empty-cart">
                    <span><Icon name="bag" size={27} /></span>
                    <h3>Your bag is ready</h3>
                    <p>Explore the latest collection and add something you love.</p>
                    <button onClick={() => setCartOpen(false)}>Continue shopping</button>
                  </div>
                ) : (
                  Object.entries(cart).map(([id, quantity]) => {
                    const product = products.find((item) => item.id === Number(id));
                    if (!product) return null;
                    return (
                      <div className="cart-item" key={id}>
                        <img src={product.image} alt={product.name} />
                        <div className="cart-item-info">
                          <span>{product.category}</span>
                          <h3>{product.name}</h3>
                          <p>{product.tone}</p>
                          <div className="quantity">
                            <button onClick={() => updateQuantity(product.id, -1)}><Icon name="minus" size={14} /></button>
                            <b>{quantity}</b>
                            <button onClick={() => updateQuantity(product.id, 1)}><Icon name="plus" size={14} /></button>
                          </div>
                        </div>
                        <strong>${product.price * quantity}</strong>
                      </div>
                    );
                  })
                )}
              </div>
              {cartCount > 0 && (
                <div className="cart-footer">
                  <div><span>Subtotal</span><strong>${cartTotal}</strong></div>
                  <p>Shipping calculated at checkout</p>
                  <button className="primary-button">Checkout <Icon name="arrow" size={18} /></button>
                </div>
              )}
            </aside>
          </div>
        )}
      </section>

      <aside className="review-note">
        <span>INTERACTIVE PROTOTYPE</span>
        <h2>A clearer way to find your next favorite.</h2>
        <p>Explore the mobile experience and test the core shopping journey.</p>
        <ul>
          <li><i>01</i><span><strong>Browse</strong> Filter by category</span></li>
          <li><i>02</i><span><strong>Discover</strong> Open any product</span></li>
          <li><i>03</i><span><strong>Decide</strong> Save or add to bag</span></li>
        </ul>
        <small>Designed for stakeholder review · v1.0</small>
      </aside>
    </main>
  );
}
